package com.dawn.apollo.malfunctionservice;

import android.support.v7.app.AppCompatActivity;
import android.view.View;

/**
 * Created by dawn-pc on 2016/4/12.
 */
public class MalfunctionActivity extends AppCompatActivity implements View.OnClickListener {



    @Override
    public void onClick(View v) {

    }
}
