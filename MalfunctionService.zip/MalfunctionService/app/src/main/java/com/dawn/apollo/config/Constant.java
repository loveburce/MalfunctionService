package com.dawn.apollo.config;

/**
 * Created by dawn-pc on 2016/4/12.
 */
public class Constant {
    public static final String PublicKey = "Flzx@SqcYsyh*Ljt"; //skey = Flzx@SqcYsyh*Ljt
    public static final String getAllChannel = "http://101.200.81.29/data/chunnels"; //获取隧道列表
    public static final String submitTrouble = "http://101.200.81.29/data/addConserve";//添加故障申报
}
